#include <iostream>
#include <vector>
using namespace std;

int coinChange(vector<int> coins, int amount) {
	vector<vector<int>> solve(amount+1, vector<int> (coins.size()));
}
int main() {
	
}