#include <bits/stdc++.h>
using namespace std;

int main()
{
	#ifndef ONLINE_JUDGE
		freopen("input.txt", "r", stdin);
		freopen("output.txt", "w", stdout);
	#endif

		int x,y,sum;
		cout <<"Enter the value:\n";
		cin >>x>>y;
		cout <<"Sum is "<<sum<<endl;

    return 0; 

}