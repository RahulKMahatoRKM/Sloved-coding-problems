#include <iostream>
using namespace std;

int main()
{
	string str = "ABCDEF";

	str.erase(0,1);

	cout<<str<<endl;

}