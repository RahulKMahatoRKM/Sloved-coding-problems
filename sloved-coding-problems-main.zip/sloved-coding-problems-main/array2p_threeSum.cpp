#include <iostream>
#include <vector>
using namespace std;

int main() {
	vector<int> vec{-1, 0, 2, 4, 5, 8, 9};

	threeSum(vec, );
}